# Health Insurance TPA Market Dataset

This repository contains a structured dataset created from publicly available summary data of the **Health Insurance TPA Market (Report Code BF3574)** from NextMSC.

## Files Included
- `market_overview.csv`
- `segmentation.csv`
- `metadata.json`
- `README.md`

## Source
https://www.nextmsc.com/report/health-insurance-tpa-market-bf3574

## Disclaimer
This dataset is for educational and research purposes. It includes only public summary data, not full proprietary report content.
